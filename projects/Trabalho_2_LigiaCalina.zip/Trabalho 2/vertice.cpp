/* Ling. Prog. 24.1 - Ligia Calina Bueno Bonifacio - Exercicio Avaliado 2
*  Arquivo auxiliar
*  Este e um arquivo auxiliar, no qual implemento as funcoes definidas no arquivo de cabecalho da classe vertice.
*/

#include "vertice.hpp"

using namespace std;

void Vertice::setNomeDaCidade(string nome) { nomeDaCidade = nome; }
string Vertice::getNomeDaCidade() { return nomeDaCidade; }
